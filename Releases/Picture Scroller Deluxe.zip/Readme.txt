=====================================================
		Picture Scroller 2.0 Deluxe
		      1/14/2001
=====================================================

CONTENTS
--------
License

System Requirements

Installation

What's New in this Version

Contacting Us

LICENSE
-------
Simply stated, this copy of Picture Scroller 2.0 Deluxe is licensed to the
purchaser.  Under the terms of the license, this copy of Picture Scroller
may be used on any number of computers owned by the purchaser or any of
his/her immediate family.  The complete license agreement can be found in
the file named "License.txt".

SYSTEM REQUIREMENTS
-------------------
Operating System:	Windows 95, 98, or 2000

			Picture Scroller has been verified to work on these systems,
			but may also work on Windows NT and most certainly should
			work on Windows Me.  For optimum performance, Windows 98 or
			greater is recommended.

DirectX:		DirectX 7.0 or greater

			If you are running Windows 95, 98, or NT but have not
			previously installed this version of DirectX, you will need
			to download it from Microsoft's site (see below).

Internet Explorer:	Internet Explorer 4.0 or later

			If you are running Windows 95 without Internet Explorer 4.0
			or greater, you will need to install it.  See below for the
			link to the Microsoft site for download information.

CPU, Video card, etc:	As with any graphics related program, the better the system
			(a higher Mhz CPU, a better Video card, etc.) the better
			Picture Scroller will run.  Nevertheless, Picture Scroller
			has been successfully tested on a Pentium 60Mhz CPU with a
			1MB Video card.

DOWNLOADS:
	DirectX: http://www.microsoft.com/directx/homeuser/downloads/default.asp
	Internet Explorer: http://www.microsoft.com/windows/ie/default.htm

INSTALLATION
------------
To install Picture Scroller, run the included setup file and follow through the
specified steps.  Please also be sure that your computer meets the system
requirements shown above.

WHAT'S NEW IN THIS VERSION
--------------------------
For a listing of what's new in this version, see the included help file after
installing Picture Scroller 2.0.

CONTACTING US
-------------
We encourage you to send us any and all questions, comments, or ideas that you may
have.  Input from users like you is what makes Picture Scroller what it is.  We will
do our best to incorporate your advice in future versions of Picture Scroller.

E-Mail: Picture_Scroller@yahoo.com
Web Page: http://pages.zdnet.com/picture_scroller/main

Thank you for using Picture Scroller!